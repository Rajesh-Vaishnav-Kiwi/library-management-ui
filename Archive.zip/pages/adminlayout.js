import React from 'react'
import Layout from '../components/Admin/Layout'
import login from './login'
import { withRouter } from 'next/router'
import { useRouter } from 'next/router'
const adminlayout = (props) => {
  console.log(props.router.query);
  const router = useRouter()
  
  
  return (
    <>
    <div>
      hii
      </div></>
  )
}

export default withRouter(adminlayout)